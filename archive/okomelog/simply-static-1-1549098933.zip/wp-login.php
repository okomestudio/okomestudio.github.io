<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-US" xmlns:fb="https://www.facebook.com/2008/fbml" xmlns:addthis="https://www.addthis.com/help/api-spec" >
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US" xmlns:fb="https://www.facebook.com/2008/fbml" xmlns:addthis="https://www.addthis.com/help/api-spec" >
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; okomelog &#8212; WordPress</title>
	<link rel='dns-prefetch' href='//s.w.org' />
<script type='text/javascript' src='./wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='./wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='./wp-content/plugins/jetpack/modules/sso/jetpack-sso-login.js?ver=6.9'></script>
<link rel='stylesheet' id='dashicons-css'  href='./wp-includes/css/dashicons.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='./wp-includes/css/buttons.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css'  href='./wp-admin/css/forms.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css'  href='./wp-admin/css/l10n.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='./wp-admin/css/login.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='genericons-css'  href='./wp-content/plugins/jetpack/_inc/genericons/genericons/genericons.css?ver=3.1' type='text/css' media='all' />
<link rel='stylesheet' id='jetpack-sso-login-css'  href='./wp-content/plugins/jetpack/modules/sso/jetpack-sso-login.css?ver=6.9' type='text/css' media='all' />
			<style>
				.jetpack-sso .message {
					margin-top: 20px;
				}

				.jetpack-sso #login .message:first-child,
				.jetpack-sso #login h1 + .message {
					margin-top: 0;
				}
			</style>
			<meta name='robots' content='noindex,noarchive' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
		</head>
	<body class="login login-action-login wp-core-ui  locale-en-us jetpack-sso jetpack-sso-form-display">
		<div id="login">
		<h1><a href="https://wordpress.org/" title="Powered by WordPress" tabindex="-1">Powered by WordPress</a></h1>
	
<form name="loginform" id="loginform" action="./" method="post">
	<p>
		<label for="user_login">Username or Email Address<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_pass">Password<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
			<div id="jetpack-sso-wrap">
			

			<div id="jetpack-sso-wrap__action">
				<a rel="nofollow" href="./?action=jetpack-sso" class="jetpack-sso button button-primary"><span><span class="genericon genericon-wordpress"></span> Log in with WordPress.com</span></a>
									<p>
						You can now save time spent logging in by connecting your WordPress.com account to okomelog.					</p>
							</div>

							<div class="jetpack-sso-or">
					<span>Or</span>
				</div>

				<a href="./?jetpack-sso-show-default-form=1" class="jetpack-sso-toggle wpcom">
					Log in with username and password				</a>

				<a href="./?jetpack-sso-show-default-form=0" class="jetpack-sso-toggle default">
					Log in with WordPress.com				</a>
					</div>
			<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
		<input type="hidden" name="redirect_to" value="./wp-admin/" />
		<input type="hidden" name="testcookie" value="1" />
	</p>
</form>

<p id="nav">
	<a href="./?action=lostpassword">Lost your password?</a>
</p>

<script type="text/javascript">
function wp_attempt_focus(){
setTimeout( function(){ try{
d = document.getElementById('user_login');
d.focus();
d.select();
} catch(e){}
}, 200);
}

wp_attempt_focus();
if(typeof wpOnload=='function')wpOnload();
</script>

	<p id="backtoblog"><a href="./index.html">&larr; Back to okomelog</a></p>
		
	</div>

	
	<link rel='stylesheet' id='jetpack_css-css'  href='./wp-content/plugins/jetpack/css/jetpack.css?ver=6.9' type='text/css' media='all' />
	<div class="clear"></div>
	</body>
	</html>
	